import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  Download,
  FileText,
  Filter,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Search,
  BarChart3,
  PieChart,
  Target,
  Activity,
  Sparkles,
  Sunrise,
  Sunset,
  Crown,
  MessageSquare,
  Check,
  KeyRound,
  ShieldCheck,
  Terminal,
  WifiOff,
  Wifi,
  Coffee,
} from 'lucide-react';
import {
  AttendanceRecord,
  CeoComment,
  Employee,
  OfficeSettings,
  ShiftSchedule,
} from '../../types';
import {
  calculateBreaksDuration,
  calculateWorkedMinutes,
  deriveLiveAttendanceState,
  formatMinutesToDecimal,
  formatMinutesToHoursMinutes,
  formatTime12h,
  getDayName,
  getLiveWorkedStats,
  getTodayDateString,
} from '../../lib/attendanceCalculations';
import { exportAttendanceToCsv } from '../../lib/exportUtils';
import {
  canEmployeeAutoPunch,
  downloadAutoStartScriptForUser,
} from '../../lib/autoStartScript';

interface MyAttendanceTabProps {
  currentUser: Employee;
  records: AttendanceRecord[];
  shifts: ShiftSchedule[];
  settings: OfficeSettings;
  onOpenPrintModal: (employee: Employee, filteredRecords: AttendanceRecord[]) => void;
  ceoComments?: CeoComment[];
  onMarkCeoCommentRead?: (commentId: string) => void;
  onOpenChangePassword?: () => void;
  isNetworkOnline?: boolean;
}

export const MyAttendanceTab: React.FC<MyAttendanceTabProps> = ({
  currentUser,
  records,
  shifts,
  settings,
  onOpenPrintModal,
  ceoComments = [],
  onMarkCeoCommentRead,
  onOpenChangePassword,
  isNetworkOnline = true,
}) => {
  // Strict filter: ONLY records belonging to currentUser!
  const myAllRecords = useMemo(() => {
    return records.filter((r) => r.employeeId === currentUser.id);
  }, [records, currentUser.id]);

  const userShift = useMemo(() => {
    return shifts.find((s) => s.id === currentUser.shiftId) || shifts[0];
  }, [shifts, currentUser.shiftId]);

  const [dateRange, setDateRange] = useState<'all' | 'month' | 'last_month' | 'custom'>('month');
  const [customStart, setCustomStart] = useState<string>('');
  const [customEnd, setCustomEnd] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [batDownloaded, setBatDownloaded] = useState<boolean>(false);

  const canPersonalAutoStart = canEmployeeAutoPunch(currentUser, settings);

  const handleDownloadAutoStartBat = async () => {
    await downloadAutoStartScriptForUser({ employee: currentUser, settings });
    setBatDownloaded(true);
    setTimeout(() => setBatDownloaded(false), 3000);
  };

  // Calculate filtered records
  const filteredRecords = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    return myAllRecords
      .filter((r) => {
        // Status filter
        if (statusFilter !== 'all' && r.status !== statusFilter) return false;

        // Search in notes or day
        if (searchTerm) {
          const term = searchTerm.toLowerCase();
          const matchNote = r.notes?.toLowerCase().includes(term);
          const dayName = r.day || (r.date ? getDayName(r.date) : '');
          const matchDay = dayName.toLowerCase().includes(term);
          const matchDate = r.date.includes(term);
          if (!matchNote && !matchDay && !matchDate) return false;
        }

        // Date range
        const recDate = new Date(r.date + 'T00:00:00');
        if (dateRange === 'month') {
          return recDate.getFullYear() === currentYear && recDate.getMonth() === currentMonth;
        } else if (dateRange === 'last_month') {
          const lastMonthDate = new Date(currentYear, currentMonth - 1, 1);
          return (
            recDate.getFullYear() === lastMonthDate.getFullYear() &&
            recDate.getMonth() === lastMonthDate.getMonth()
          );
        } else if (dateRange === 'custom') {
          if (customStart && r.date < customStart) return false;
          if (customEnd && r.date > customEnd) return false;
          return true;
        }
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [myAllRecords, dateRange, customStart, customEnd, statusFilter, searchTerm]);

  // Aggregate statistics
  const stats = useMemo(() => {
    let totalWorkedMins = 0;
    let totalRegularMins = 0;
    let totalOvertimeMins = 0;
    let presentCount = 0;
    let lateCount = 0;
    const todayStrNow = getTodayDateString();

    filteredRecords.forEach((r) => {
      const liveState = deriveLiveAttendanceState({
        record: r,
        settings,
        todayStr: todayStrNow,
        isCurrentUserOffline: !isNetworkOnline,
        isCurrentUserConnected: isNetworkOnline,
      });
      const worked = getLiveWorkedStats({ record: r, shift: userShift, settings, liveState });
      totalWorkedMins += worked.totalWorkedMinutes;
      totalRegularMins += worked.regularMinutes;
      totalOvertimeMins += worked.overtimeMinutes;
      if (r.status === 'present') presentCount++;
      if (r.status === 'late') {
        presentCount++;
        lateCount++;
      }
    });

    const onTimeRate = presentCount > 0 ? Math.round(((presentCount - lateCount) / presentCount) * 100) : 100;

    return {
      totalWorkedMins,
      totalRegularMins,
      totalOvertimeMins,
      presentCount,
      lateCount,
      onTimeRate,
    };
  }, [filteredRecords, userShift, settings, isNetworkOnline]);

  // Current week worked minutes calculation (Monday through Sunday)
  const currentWeekStats = useMemo(() => {
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 is Sun, 1 is Mon...
    const diffToMon = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
    const monday = new Date(today);
    monday.setDate(today.getDate() + diffToMon);
    monday.setHours(0, 0, 0, 0);

    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);

    const monStr = monday.toISOString().slice(0, 10);
    const sunStr = sunday.toISOString().slice(0, 10);

    const weekRecords = myAllRecords.filter((r) => r.date >= monStr && r.date <= sunStr);
    const weekWorkedMins = weekRecords.reduce((acc, r) => {
      let m = r.totalWorkedMinutes || 0;
      if (r.timeIn && r.timeOut && (!m || m === 0)) {
        const c = calculateWorkedMinutes(r.timeIn, r.timeOut, r.breaks, userShift?.expectedHours || 8);
        m = c.totalWorkedMinutes;
      }
      return acc + m;
    }, 0);
    const targetMins = 40 * 60; // 40 hours target
    const percent = Math.min(100, Math.round((weekWorkedMins / targetMins) * 100));

    return {
      weekWorkedMins,
      targetMins,
      percent,
      monStr,
      sunStr,
    };
  }, [myAllRecords, userShift]);

  // Chronological recent days (up to 10 days) for the interactive bar chart
  const recentDaysForChart = useMemo(() => {
    const slice = filteredRecords.slice(0, 10).reverse();
    return slice.map((r) => {
      let totalMins = r.totalWorkedMinutes || 0;
      let regMins = r.regularMinutes || 0;
      let otMins = r.overtimeMinutes || 0;
      if (r.timeIn && r.timeOut && (!totalMins || totalMins === 0)) {
        const calc = calculateWorkedMinutes(r.timeIn, r.timeOut, r.breaks, userShift?.expectedHours || 8);
        totalMins = calc.totalWorkedMinutes;
        regMins = calc.regularMinutes;
        otMins = calc.overtimeMinutes;
      }
      const workedHours = totalMins / 60;
      const regularHours = regMins / 60;
      const overtimeHours = otMins / 60;
      const dayStr = r.day || (r.date ? getDayName(r.date) : 'Day');
      return {
        id: r.id,
        date: r.date,
        shortDate: r.date.slice(5),
        day: dayStr.slice(0, 3),
        fullDay: dayStr,
        timeIn: r.timeIn,
        timeOut: r.timeOut,
        workedHours,
        regularHours,
        overtimeHours,
        totalWorkedMinutes: totalMins,
        isLate: r.status === 'late',
      };
    });
  }, [filteredRecords, userShift]);

  const handleDownloadCsv = () => {
    exportAttendanceToCsv({
      records: filteredRecords,
      employees: [currentUser],
      shifts,
      settings,
      employeeFilter: currentUser,
      startDate: customStart || undefined,
      endDate: customEnd || undefined,
    });
  };

  const todayStr = getTodayDateString();
  const dayName = getDayName(todayStr);

  const myCeoDirectives = useMemo(() => {
    return ceoComments.filter((c) => c.employeeId === currentUser.id);
  }, [ceoComments, currentUser.id]);

  return (
    <div className="space-y-6">
      {/* Unread Executive Directives Banner */}
      {myCeoDirectives.filter((c) => !c.isRead).length > 0 && (
        <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/60 border-2 border-amber-300 dark:border-amber-700 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-200 font-bold text-xs">
              <Crown className="w-4 h-4 text-amber-600" />
              <span>Official Executive Mentions / Directives ({myCeoDirectives.filter((c) => !c.isRead).length})</span>
            </div>
            <span className="text-[10px] text-amber-600 dark:text-amber-400 font-medium uppercase tracking-wider">
              High Priority
            </span>
          </div>
          <div className="space-y-2">
            {myCeoDirectives
              .filter((c) => !c.isRead)
              .map((comment) => (
                <div
                  key={comment.id}
                  className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-900 dark:text-slate-100">
                        {comment.fromName} ({comment.fromRole.toUpperCase()})
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(comment.createdAt).toLocaleDateString()} {new Date(comment.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                      "{comment.message}"
                    </p>
                  </div>
                  {onMarkCeoCommentRead && (
                    <button
                      onClick={() => onMarkCeoCommentRead(comment.id)}
                      className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/40 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-200 text-xs font-semibold transition-colors cursor-pointer"
                      title="Acknowledge directive"
                    >
                      <Check className="w-3 h-3" />
                      <span>Mark Read</span>
                    </button>
                  )}
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Header with Title and Download Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <span>My Personal Attendance & Stats</span>
            </h1>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-100/90 dark:bg-emerald-950/80 border-2 border-emerald-400 dark:border-emerald-600 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-black text-emerald-900 dark:text-emerald-200">
                {todayStr}
              </span>
              <span className="text-emerald-500 font-bold">•</span>
              <span className="text-xs font-black text-emerald-800 dark:text-emerald-300 uppercase tracking-wide">
                {dayName}
              </span>
            </div>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Individual timesheet records for {currentUser.name} ({currentUser.employeeCode})
          </p>
        </div>

        {/* Export & Print Timesheet Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleDownloadCsv}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 shadow-2xs transition-colors cursor-pointer"
            title="Download personal attendance ledger to Excel / CSV"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" />
            <span>Download My Stats (CSV)</span>
          </button>

          <button
            onClick={() => onOpenPrintModal(currentUser, filteredRecords)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-colors cursor-pointer"
            title="Open printable official timesheet"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Print Official Timesheet (PDF)</span>
          </button>
        </div>
      </div>

      {/* Account Credentials & Windows Auto-Start Card */}
      <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900/50 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 flex-wrap">
              <span>Portal Credentials &amp; Windows Auto-Start</span>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-[10px] font-bold text-indigo-700 dark:text-indigo-300" title="Attendance Tracker">
                <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="11" cy="12" r="8" stroke="currentColor" strokeWidth="2" />
                  <path d="M11 8v4l2.5 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  <circle cx="18" cy="17" r="4.5" className="fill-emerald-500 stroke-white dark:stroke-slate-900" strokeWidth="1.5" />
                  <path d="M16.2 17l1.2 1.2 2.4-2.4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>AT · Attendance Tracker</span>
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Download the Windows Startup (.bat) app or update your portal login PIN. Attendance is secured by Office Wi-Fi / IP Restriction.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto justify-end">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[10px] font-bold text-slate-700 dark:text-slate-200" title="Attendance Tracker .bat Launcher">
            <svg className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="11" cy="12" r="8" stroke="currentColor" strokeWidth="2" />
              <path d="M11 8v4l2.5 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="18" cy="17" r="4.5" className="fill-emerald-500 stroke-white dark:stroke-slate-900" strokeWidth="1.5" />
              <path d="M16.2 17l1.2 1.2 2.4-2.4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span>AT .bat</span>
          </span>
          <button
            type="button"
            onClick={handleDownloadAutoStartBat}
            className={`flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
              batDownloaded
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800'
            }`}
            title={
              canPersonalAutoStart
                ? 'Download Windows startup app (.bat) to auto-start portal & auto mark Time In when booting on office Wi-Fi'
                : 'Download Windows auto-start launcher (.bat) to auto-open Attendance Tracker on Windows startup for manual ID/PIN punching'
            }
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>
              {batDownloaded ? 'Downloaded .bat!' : 'Download Auto-Start (.bat)'}
            </span>
          </button>

          {onOpenChangePassword && (
            <button
              type="button"
              onClick={onOpenChangePassword}
              className="flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-2xs transition-colors cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Change Password / PIN</span>
            </button>
          )}
        </div>
      </div>

      {/* Totally Separate Live Attendance & Connection Status Bar */}
      {(() => {
        const todayRecordForBar = myAllRecords.find((r) => r.date === todayStr);
        const todayStatusForBar = deriveLiveAttendanceState({
          record: todayRecordForBar,
          settings,
          todayStr,
          isCurrentUserOffline: !isNetworkOnline,
          isCurrentUserConnected: isNetworkOnline,
        });
        const todayWorked = getLiveWorkedStats({
          record: todayRecordForBar,
          shift: userShift,
          settings,
          liveState: todayStatusForBar,
        });
        return (
          <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                  todayStatusForBar === 'in'
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                    : todayStatusForBar === 'no_internet' || todayStatusForBar === 'break'
                    ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {todayStatusForBar === 'no_internet' ? (
                  <WifiOff className="w-4 h-4 animate-pulse" />
                ) : todayStatusForBar === 'break' ? (
                  <Coffee className="w-4 h-4" />
                ) : (
                  <Wifi className="w-4 h-4" />
                )}
              </div>
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Today&apos;s Live Attendance Status Bar
                </div>
                <div className="text-sm font-bold text-slate-900 dark:text-slate-100 flex flex-wrap items-center gap-2 mt-0.5">
                  <span>
                    {todayStatusForBar === 'in'
                      ? 'Online · Working'
                      : todayStatusForBar === 'break'
                      ? 'On Break'
                      : todayStatusForBar === 'no_internet'
                      ? 'No Internet · Offline (Still In)'
                      : todayStatusForBar === 'out'
                      ? `Shift Ended · Punched Out (${formatTime12h(todayRecordForBar?.timeOut)})`
                      : isNetworkOnline
                      ? 'Online · Not Clocked In Today'
                      : 'Offline · Not Clocked In Today'}
                  </span>
                  {todayWorked.isLiveOvertime && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-200 border border-amber-300 dark:border-amber-700">
                      Live Overtime (+{formatMinutesToHoursMinutes(todayWorked.overtimeMinutes)})
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs">
              <div className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 block uppercase">Punch In</span>
                <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                  {todayRecordForBar?.timeIn ? formatTime12h(todayRecordForBar.timeIn) : '—'}
                </span>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 block uppercase">Punch Out</span>
                <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                  {todayRecordForBar?.timeOut ? formatTime12h(todayRecordForBar.timeOut) : '—'}
                </span>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 block uppercase">Connection</span>
                <span className={`font-bold ${isNetworkOnline ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                  {isNetworkOnline ? 'Connected' : 'Offline'}
                </span>
              </div>
            </div>
          </div>
        );
      })()}

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Hours Worked */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Total Hours Worked
            </span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {formatMinutesToHoursMinutes(stats.totalWorkedMins)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {formatMinutesToDecimal(stats.totalWorkedMins)} total decimal hours
          </p>
        </div>

        {/* Regular vs Overtime */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Overtime Hours
            </span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-2 tabular-nums">
            {formatMinutesToHoursMinutes(stats.totalOvertimeMins)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Regular: {formatMinutesToHoursMinutes(stats.totalRegularMins)}
          </p>
        </div>

        {/* Days Present */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Days Present
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {stats.presentCount} days
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            In current selected period
          </p>
        </div>

        {/* Punctuality Rate */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              On-Time Punctuality
            </span>
            <AlertTriangle className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-2 tabular-nums">
            {stats.onTimeRate}%
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {stats.lateCount} late arrival{stats.lateCount === 1 ? '' : 's'} flagged
          </p>
        </div>
      </div>

      {/* Graphical Representation of Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Daily Worked Hours Interactive Bar Chart (2 cols) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 flex items-center justify-center">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Daily Work Hours Trend
                </h3>
                <p className="text-[11px] text-slate-400">
                  Logged hours with 8.0h standard shift guideline & overtime highlights
                </p>
              </div>
            </div>

            {/* Chart Legend */}
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
                <span className="w-2.5 h-2.5 rounded-xs bg-blue-500"></span>
                Regular (up to 8h)
              </span>
              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-500"></span>
                Overtime
              </span>
              <span className="flex items-center gap-1.5 text-purple-600 dark:text-purple-400 font-semibold">
                <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                Late Arrival
              </span>
            </div>
          </div>

          {/* Bar Chart Container */}
          {recentDaysForChart.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No daily attendance records in this period to graph.
            </div>
          ) : (
            <div className="relative pt-7 pb-2">
            <div className="relative h-44 ml-8 sm:ml-9 mr-1 border-b border-slate-200 dark:border-slate-800">
              {/* Left Y-Axis Hour Representation */}
              {[12, 8, 4, 0].map((h) => (
                <div
                  key={h}
                  className="absolute -left-8 sm:-left-9 translate-y-1/2 w-7 sm:w-8 flex items-center justify-end pr-1 pointer-events-none select-none text-[9px] font-mono text-slate-400"
                  style={{ bottom: `${(h / 12) * 100}%` }}
                >
                  <span className="pr-1">{h}h</span>
                  <div className="w-1 h-px bg-slate-300 dark:bg-slate-700" />
                </div>
              ))}

              {/* Horizontal Reference Grid Lines */}
              {[12, 8, 4].map((h) => (
                <div
                  key={`grid-${h}`}
                  className="absolute inset-x-0 border-t border-slate-200/50 dark:border-slate-800/50 pointer-events-none"
                  style={{ bottom: `${(h / 12) * 100}%` }}
                />
              ))}

              {/* 8.0h Target Reference Line across chart */}
              <div
                className="absolute inset-x-0 border-b-2 border-dashed border-emerald-400/80 dark:border-emerald-600 z-20 pointer-events-none flex items-center justify-end pr-1"
                style={{ bottom: `${(8 / 12) * 100}%` }}
                title="8.0h Standard Target"
              >
                <span className="-translate-y-1/2 text-[9px] sm:text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-white/95 dark:bg-slate-900/95 px-1.5 py-0.5 rounded shadow-2xs border border-emerald-200 dark:border-emerald-800">
                  8.0h Standard Shift
                </span>
              </div>

              {/* Chart Plot Area */}
              <div className="relative z-10 h-full flex items-end justify-between gap-1 sm:gap-2 px-1 sm:px-2">
                {recentDaysForChart.map((d) => {
                  const maxChartHours = 12;
                const totalPercent = d.workedHours > 0 ? Math.min(100, Math.max(4, (d.workedHours / maxChartHours) * 100)) : 2;
                const hasOvertime = d.workedHours > 8 || d.overtimeHours > 0;
                const regularPercent = d.workedHours > 0
                  ? (hasOvertime ? (Math.min(8, d.workedHours) / d.workedHours) * 100 : 100)
                  : 100;
                const overtimePercent = hasOvertime && d.workedHours > 0
                  ? (Math.max(0, d.workedHours - 8) / d.workedHours) * 100
                  : 0;

                  return (
                    <div
                      key={d.id}
                      className="group relative min-w-0 flex-1 flex flex-col items-center h-full justify-end cursor-pointer"
                    >
                      {/* Hover Tooltip Card */}
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none absolute -top-16 z-30 bg-slate-900 text-white text-[10px] rounded-lg py-1.5 px-2.5 shadow-xl whitespace-nowrap">
                        <p className="font-bold text-emerald-400">
                          {d.fullDay}, {d.date}
                        </p>
                        <p className="text-slate-200">
                          Total: <strong className="text-white">{d.workedHours.toFixed(1)}h</strong> ({d.timeIn ? formatTime12h(d.timeIn) : '—'} - {d.timeOut ? formatTime12h(d.timeOut) : 'In Progress'})
                        </p>
                        {d.overtimeHours > 0 && (
                          <p className="text-amber-300 font-semibold">
                            +{d.overtimeHours.toFixed(1)}h Overtime
                          </p>
                        )}
                        {d.isLate && <p className="text-purple-300 font-bold">Late Arrival</p>}
                      </div>

                      {/* Top Hours Label with visible badge on each bar */}
                      <span style={{ bottom: `calc(${totalPercent}% + 4px)` }} className={`absolute left-1/2 -translate-x-1/2 z-20 pointer-events-none text-[8px] sm:text-[9px] font-mono font-bold px-1 py-0.2 rounded border shadow-2xs whitespace-nowrap ${
                        d.workedHours > 0
                          ? d.isLate
                            ? 'bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border-purple-300 dark:border-purple-800'
                            : 'bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border-blue-300 dark:border-blue-800'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
                      }`}>
                        {d.workedHours.toFixed(1)}h
                      </span>

                      {/* Bar Visual (Regular + Overtime stacked) */}
                      <div
                        className="w-full max-w-[36px] shrink-0 rounded-t-md overflow-hidden flex flex-col justify-end transition-all group-hover:brightness-110 shadow-xs relative"
                        style={{ height: `${totalPercent}%` }}
                      >
                        {/* Overtime stack segment */}
                        {overtimePercent > 0 && (
                          <div
                            className="w-full shrink-0 bg-gradient-to-t from-amber-500 to-amber-400 flex items-center justify-center"
                            style={{ height: `${overtimePercent}%` }}
                            title={`Overtime: ${d.overtimeHours.toFixed(1)}h`}
                          >
                            {overtimePercent >= 30 && (
                              <span className="text-[8px] font-mono font-bold text-white drop-shadow-xs">
                                +{d.overtimeHours.toFixed(1)}
                              </span>
                            )}
                          </div>
                        )}
                        {/* Regular stack segment */}
                        <div
                          className={`w-full shrink-0 flex items-center justify-center ${
                            d.isLate
                              ? 'bg-gradient-to-t from-purple-600 to-indigo-500'
                              : 'bg-gradient-to-t from-blue-600 to-emerald-500'
                          }`}
                     style={{ height: `${regularPercent}%` }}                     title={`Regular: ${d.regularHours.toFixed(1)}h`}
                        >
                          {totalPercent >= 28 && (
                            <span className="text-[9px] font-mono font-black text-white drop-shadow-xs">
                              {d.regularHours.toFixed(0)}h
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Late arrival dot indicator */}
                      {d.isLate && (
                        <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-purple-500" />
                      )}
                    </div>
                  );
                })}
              </div>
              </div>
              
              {/* X-Axis Labels */}
              <div className="flex items-center justify-between gap-2 ml-8 sm:ml-9 mr-1 px-1 sm:px-2 pt-3 text-[9px] sm:text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                {recentDaysForChart.map((d) => (
                  <div key={d.id} className="min-w-0 flex-1 text-center truncate">
                    <span className="font-semibold block">{d.day}</span>
                    <span className="text-[9px] text-slate-400">{d.shortDate}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Col: Punctuality Ring & Weekly Target Meter */}
        <div className="space-y-4 flex flex-col justify-between">
          {/* Punctuality Ring / Doughnut Chart */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-4">
            {/* SVG Ring */}
            <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  className="stroke-slate-100 dark:stroke-slate-800"
                  strokeWidth="10"
                  fill="transparent"
                />
                {/* Progress Ring (Emerald) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  className="stroke-emerald-500 transition-all duration-700 ease-out"
                  strokeWidth="10"
                  strokeDasharray="238.76"
                  strokeDashoffset={238.76 - (238.76 * stats.onTimeRate) / 100}
                  strokeLinecap="round"
                  fill="transparent"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-base font-black font-mono text-slate-900 dark:text-slate-100">
                  {stats.onTimeRate}%
                </span>
                <span className="text-[8px] uppercase tracking-wider text-slate-400 font-bold">
                  On-Time
                </span>
              </div>
            </div>

            {/* Punctuality Details */}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-slate-100">
                <PieChart className="w-3.5 h-3.5 text-emerald-600" />
                <span>Punctuality Ratio</span>
              </div>
              <div className="mt-2 space-y-1 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    On-Time:
                  </span>
                  <strong className="text-slate-900 dark:text-slate-100 font-mono">
                    {Math.max(0, stats.presentCount - stats.lateCount)} days
                  </strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                    Late Arrivals:
                  </span>
                  <strong className="text-purple-600 dark:text-purple-400 font-mono">
                    {stats.lateCount} days
                  </strong>
                </div>
              </div>
            </div>
          </div>

          {/* Weekly 40-Hour Target Meter */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-slate-100">
                <Target className="w-3.5 h-3.5 text-blue-600" />
                <span>Weekly Work Target (40h)</span>
              </div>
              <span className="text-xs font-black font-mono text-blue-600 dark:text-blue-400">
                {currentWeekStats.percent}%
              </span>
            </div>

            {/* Progress Bar Gauge */}
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden mt-3 p-0.5">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  currentWeekStats.percent >= 100
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                    : 'bg-gradient-to-r from-blue-600 to-emerald-500'
                }`}
                style={{ width: `${currentWeekStats.percent}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 font-mono">
              <span>{formatMinutesToHoursMinutes(currentWeekStats.weekWorkedMins)} logged</span>
              <span>40h target</span>
            </div>

            {currentWeekStats.percent >= 100 ? (
              <div className="mt-2 text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded px-2 py-0.5 text-center">
                🎉 Weekly 40h Target Completed!
              </div>
            ) : (
              <div className="mt-2 text-[10px] text-slate-500 text-center">
                {formatMinutesToHoursMinutes(Math.max(0, currentWeekStats.targetMins - currentWeekStats.weekWorkedMins))} remaining this week
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-4">
        {/* Period Selector Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium">
          <button
            onClick={() => setDateRange('month')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              dateRange === 'month'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setDateRange('last_month')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              dateRange === 'last_month'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Last Month
          </button>
          <button
            onClick={() => setDateRange('all')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              dateRange === 'all'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            All Logs
          </button>
          <button
            onClick={() => setDateRange('custom')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              dateRange === 'custom'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Custom Range
          </button>
        </div>

        {/* Custom Range Inputs */}
        {dateRange === 'custom' && (
          <div className="flex items-center gap-2 text-xs">
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
          </div>
        )}

        {/* Status Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100"
          >
            <option value="all">All Statuses</option>
            <option value="present">On Time Only</option>
            <option value="late">Late Arrivals</option>
          </select>
        </div>
      </div>

      {/* Attendance Records Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto pb-1">
          <table className="w-full min-w-[820px] text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <th className="py-3 px-4">Date & Day</th>
                <th className="py-3 px-4">Time In</th>
                <th className="py-3 px-4">Time Out</th>
                <th className="py-3 px-4">Break Mins</th>
                <th className="py-3 px-4 text-right">Total Hours</th>
                <th className="py-3 px-4 text-right">Overtime</th>
                <th className="py-3 px-4 text-center">Arrival</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4">Notes / Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    No attendance records found for the selected filter period.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r) => {
                  const breakMins = calculateBreaksDuration(r.breaks);
                  const liveState = deriveLiveAttendanceState({
                    record: r,
                    settings,
                    isCurrentUserOffline: !isNetworkOnline,
                    isCurrentUserConnected: isNetworkOnline,
                  });
                  const worked = getLiveWorkedStats({
                    record: r,
                    shift: userShift,
                    settings,
                    liveState,
                  });
                  return (
                    <tr
                      key={r.id}
                      className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-emerald-50/90 dark:bg-emerald-950/70 border border-emerald-300 dark:border-emerald-700/80 shadow-2xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                          <span className="font-bold text-xs text-emerald-900 dark:text-emerald-200">
                            {r.date}
                          </span>
                          <span className="text-emerald-500 font-bold">•</span>
                          <strong className="font-black text-xs text-emerald-800 dark:text-emerald-300 uppercase tracking-wide">
                            {r.day || (r.date ? getDayName(r.date) : '')}
                          </strong>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        {r.timeIn ? (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200 shadow-2xs">
                            <Sunrise className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                            <span className="font-mono font-bold text-xs">{formatTime12h(r.timeIn)}</span>
                          </div>
                        ) : (
                          <span className="text-slate-400 font-sans text-xs">—</span>
                        )}
                      </td>

                      {/* Time Out Column (Strictly Punch Out Time Only) */}
                      <td className="py-3 px-4">
                        {r.timeOut ? (
                          <div className="inline-flex flex-col">
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 shadow-2xs">
                              <Sunset className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                              <span className="font-mono font-bold text-xs">{formatTime12h(r.timeOut)}</span>
                            </div>
                            {r.isAutoPunchedOut && (
                              <span className="text-[9px] text-amber-600 dark:text-amber-400 font-sans font-semibold mt-0.5">
                                {r.autoPunchOutReason === 'shift_end_2h'
                                  ? `Auto (Shift End +${settings.autoPunchOutOnInactiveHours ?? 2}h)`
                                  : r.autoPunchOutReason === 'inactivity_2h'
                                  ? 'Auto Closed'
                                  : 'Auto 11:59 PM'}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 font-mono text-xs">—</span>
                        )}
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-400">
                        {breakMins > 0 ? `${breakMins}m` : '—'}
                      </td>

                      <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 text-right tabular-nums">
                        {formatMinutesToHoursMinutes(worked.totalWorkedMinutes)}
                      </td>

                      <td className="py-3 px-4 font-mono text-right tabular-nums">
                        {worked.overtimeMinutes > 0 ? (
                          <span className="text-amber-600 dark:text-amber-400 font-semibold">
                            +{formatMinutesToHoursMinutes(worked.overtimeMinutes)}
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        {r.status === 'late' ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300">
                            Late Arrival
                          </span>
                        ) : r.status === 'present' ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                            On Time
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 capitalize">
                            {r.status}
                          </span>
                        )}
                      </td>

                      {/* Totally Separate Live / Working Status Column */}
                      <td className="py-3 px-4 text-center">
                        {liveState === 'break' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300">
                            <Coffee className="w-3 h-3" />
                            <span>On Break</span>
                          </span>
                        ) : liveState === 'no_internet' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-200 border border-amber-300 dark:border-amber-700">
                            <WifiOff className="w-3 h-3 text-amber-600 dark:text-amber-400 animate-pulse" />
                            <span>No Internet (In)</span>
                          </span>
                        ) : liveState === 'in' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                            <Wifi className="w-3 h-3" />
                            <span>{worked.isLiveOvertime ? 'Online · Overtime' : 'Online · Working'}</span>
                          </span>
                        ) : liveState === 'out' ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                            Punched Out
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300">
                            Not In
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-slate-500 text-[11px]">
                        {r.notes || (r.isManuallyAdjusted ? `Manual edit: ${r.adjustmentNote}` : '—')}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
