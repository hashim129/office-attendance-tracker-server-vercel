import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Clock, KeyRound, User, ArrowRight, RefreshCw, Terminal, Download } from 'lucide-react';
import { Employee } from '../../types';
import { verifyEmployeePin, lookupLogin } from '../../lib/pinAuth';
import { downloadWindowsBatFile, generatePortalLauncherBat } from '../../lib/autoStartScript';

interface LoginViewProps {
  employees: Employee[];
  onLogin: (employee: Employee, keepLoggedIn: boolean) => void;
  companyName: string;
  isSyncing?: boolean;
}

export const LoginView: React.FC<LoginViewProps> = ({
  employees,
  onLogin,
  companyName,
  isSyncing = false,
}) => {
  const activeEmployees = useMemo(
    () => employees.filter((e) => e.isActive !== false),
    [employees]
  );

  const [selectedEmpId, setSelectedEmpId] = useState<string>(activeEmployees[0]?.id || '');
  const [pinInput, setPinInput] = useState<string>('');
  const [keepLoggedIn, setKeepLoggedIn] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [manualCode, setManualCode] = useState<string>('');
  const [mode, setMode] = useState<'picker' | 'manual'>('picker');
  const appliedUrlEmpRef = useRef<boolean>(false);

  // Re-sync selected employee whenever cloud database finishes loading or updates
  useEffect(() => {
    if (activeEmployees.length > 0) {
      if (!appliedUrlEmpRef.current && typeof window !== 'undefined') {
        const empParam = new URLSearchParams(window.location.search).get('emp');
        if (empParam) {
          const urlMatched = activeEmployees.find(
            (e) => e.employeeCode.toLowerCase() === empParam.trim().toLowerCase()
          );
          if (urlMatched) {
            appliedUrlEmpRef.current = true;
            setSelectedEmpId(urlMatched.id);
            setManualCode(urlMatched.employeeCode);
            return;
          }
        }
      }
      const stillExists = activeEmployees.some((e) => e.id === selectedEmpId);
      if (!selectedEmpId || !stillExists) {
        setSelectedEmpId(activeEmployees[0].id);
      }
    }
  }, [activeEmployees, selectedEmpId]);

  const selectedEmployee = activeEmployees.find((e) => e.id === selectedEmpId);

  const [isChecking, setIsChecking] = useState(false);

  const handlePickerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployee) {
      setErrorMsg('Please select a valid employee account.');
      return;
    }
    if (isChecking) return;

    // The server checks the PIN (browsers no longer receive PINs)
    setIsChecking(true);
    const result = await verifyEmployeePin(selectedEmployee, pinInput);
    setIsChecking(false);
    if (!result.ok) {
      setErrorMsg(result.error || 'Incorrect PIN or password. Please try again.');
      return;
    }

    setErrorMsg('');
    onLogin(selectedEmployee, keepLoggedIn);
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isChecking) return;
    setIsChecking(true);
    const result = await lookupLogin(manualCode, pinInput, activeEmployees);
    setIsChecking(false);

    if (!result.ok || !result.employee) {
      setErrorMsg(result.error || 'Incorrect PIN or password.');
      return;
    }

    setErrorMsg('');
    onLogin(result.employee, keepLoggedIn);
  };

  return (
    <div className="min-h-[calc(100vh-2.5rem)] flex items-center justify-center p-6 bg-slate-100/80 dark:bg-slate-950/90 relative overflow-hidden">
      {/* Subtle Windows desktop background elements */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200/80 dark:border-slate-800 p-8 z-10 transition-all">
        {/* Office Server Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 mb-3">
            <Clock className="w-8 h-8" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {companyName}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Local Server Attendance & Timesheet Portal
          </p>

          {isSyncing && (
            <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-[11px] font-medium text-blue-700 dark:text-blue-300">
              <RefreshCw className="w-3 h-3 animate-spin" />
              <span>Syncing live directory & credentials from cloud server...</span>
            </div>
          )}
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex rounded-lg bg-slate-100 dark:bg-slate-800 p-1 mb-6 text-xs font-medium">
          <button
            type="button"
            onClick={() => {
              setMode('picker');
              setErrorMsg('');
            }}
            className={`flex-1 py-1.5 rounded-md transition-colors ${
              mode === 'picker'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Staff Directory Select
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('manual');
              setErrorMsg('');
            }}
            className={`flex-1 py-1.5 rounded-md transition-colors ${
              mode === 'manual'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Employee ID / Email
          </button>
        </div>

        {/* Picker Mode Form */}
        {mode === 'picker' ? (
          <form onSubmit={handlePickerSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Select Your Account
              </label>
              <div className="relative">
                <select
                  value={selectedEmpId}
                  onChange={(e) => {
                    setSelectedEmpId(e.target.value);
                    setPinInput('');
                    setErrorMsg('');
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                >
                  {activeEmployees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.employeeCode}) — {emp.role.toUpperCase()} [{emp.department}]
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedEmployee && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold">
                    {selectedEmployee.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {selectedEmployee.name}
                    </p>
                    <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                      {selectedEmployee.designation}
                    </p>
                  </div>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider ${
                    selectedEmployee.role === 'admin'
                      ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300'
                      : selectedEmployee.role === 'ceo'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-200'
                      : selectedEmployee.role === 'accounts'
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300'
                      : 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300'
                  }`}
                >
                  {selectedEmployee.role === 'ceo' ? 'CEO' : selectedEmployee.role === 'accounts' ? 'Accounts' : selectedEmployee.role}
                </span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Security PIN / Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Enter your PIN or password"
                  maxLength={32}
                  className="w-full px-3.5 py-2.5 pl-10 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  required
                />
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            {/* Keep Logged In Option */}
            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 text-slate-600 dark:text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={keepLoggedIn}
                  onChange={(e) => setKeepLoggedIn(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span>Keep me logged in on this device</span>
              </label>
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/30 p-2.5 rounded-lg border border-rose-200 dark:border-rose-900/50">
                {errorMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={isChecking}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <span>Sign In to Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          /* Manual Mode Form */
          <form onSubmit={handleManualSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Employee Code or Work Email
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="e.g. EMP-101 or admin@office.local"
                  className="w-full px-3.5 py-2.5 pl-10 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  required
                />
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Security PIN / Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Enter your PIN or password"
                  maxLength={32}
                  className="w-full px-3.5 py-2.5 pl-10 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  required
                />
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 text-slate-600 dark:text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={keepLoggedIn}
                  onChange={(e) => setKeepLoggedIn(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                <span>Keep me logged in</span>
              </label>
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/30 p-2.5 rounded-lg border border-rose-200 dark:border-rose-900/50">
                {errorMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={isChecking}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <span>Verify & Sign In</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Windows Startup Auto-Start App (.bat) Download */}
        <div className="mt-6 pt-4 border-t border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
            <Terminal className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span>Auto-open on Windows startup (Manual ID Punch)</span>
          </div>
          <button
            type="button"
            onClick={() => {
              const appUrl =
                typeof window !== 'undefined'
                  ? window.location.origin
                  : 'https://office-attendance-tracker-server-ve.vercel.app';
              const { filename, content } = generatePortalLauncherBat({ appUrl, companyName });
              downloadWindowsBatFile(filename, content);
            }}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 transition-colors cursor-pointer shrink-0"
            title="Download Windows .bat to auto-start this app on boot/login so you can select your ID and punch manually"
          >
            <Download className="w-3 h-3" />
            <span>Get .bat</span>
          </button>
        </div>
      </div>
    </div>
  );
};
